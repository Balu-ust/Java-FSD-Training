export class Patient {
    id : number;
    firstName: String ;
    lastName: string ;
    address: string ;
    active: boolean ;
}