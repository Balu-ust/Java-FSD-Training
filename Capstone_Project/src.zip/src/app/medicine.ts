export class Medicine{

    id :number;
    medName:String;
    quantity:String;
    price:String;
    active: boolean ;

}