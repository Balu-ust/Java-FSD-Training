import React from 'react';

function SpringBoot(props){
    return(
        <div>
            <h2>SpringBoot</h2>
            <p>Spring Boot makes it easy to create stand-alone, production-grade Spring based Applications that you can "just run".

We take an opinionated view of the Spring platform and third-party libraries so you can get started with minimum fuss. Most Spring Boot applications need minimal Spring configuration.</p>
        </div>
        
       
    );
}

export default SpringBoot;