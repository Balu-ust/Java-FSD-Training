import React from 'react';

function GCP(props){
    return(
        <div>
            <h2>Google Cloud Platform</h2>
            <p>Google Cloud Platform, offered by Google, is a suite of cloud computing services that runs on the same infrastructure that Google uses internally for its end-user products, such as Google Search, Gmail, file storage, and YouTube</p>
            </div>
        
       
    );
}

export default GCP;