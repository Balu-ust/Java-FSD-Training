import React from 'react';

function Home(props){
    return(
        <div>
            <p>Computer courses are one of the most popular and sought-after courses that are amongst the top choices for all engineering aspirants. Computer courses are further bifurcated into IT and software engineering courses.</p>
  <p>Computer Courses List is endless and is bifurcated into full-time undergraduate and postgraduate computer courses, online computer courses, or short-term certificate and diploma in computer courses. BTech Computer Science, BCA at the bachelor’s level, and MTech CSE, MCA at the master's level are popular computer courses for which the admissions are either merit-based or based on JEE Main, GATE, or other engineering entrance exams scores.</p>
  
   </div>
    );
}

export default Home;