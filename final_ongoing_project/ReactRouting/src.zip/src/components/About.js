import React from 'react';

function About(props){
   



    return(
        <div>
            <p>A company profile is an introduction to your business, and aims to tell an audience about your products or services. However, a company profile shouldn't just tell your audience what you sell -- it should also tell viewers why you sell it. A company profile often includes a compelling story about how the company began, as well as the company's vision and values.</p>
       
           

       </div>

    );
}

export default About;