import React from 'react';

function JavaBasics(props){
    return(
        <div>
            <h2>Java</h2>
            <p>Java is one of the most popular programming languages out there. Released in 1995 and still widely used today, Java has many applications, including software development, mobile applications, and large systems development. Knowing Java opens a lot of possibilities for you as a developer.</p>
            
            <h4>Why we love it:</h4>
            <p>Versatility
Object-oriented programming
Great place to start
Excellent online documentation</p>
            </div>
        
       
    );
}

export default JavaBasics;